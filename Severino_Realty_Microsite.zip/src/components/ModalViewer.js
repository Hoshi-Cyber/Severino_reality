export function renderModalViewer(id, content) {
  return `<div class="modal" id="${id}"><div class="modal-content">${content}</div></div>`;
}
