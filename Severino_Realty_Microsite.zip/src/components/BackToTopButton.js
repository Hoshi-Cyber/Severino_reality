export function renderBackToTopButton() {
  return `<button id="backToTop" class="back-to-top">↑ Top</button>`;
}
