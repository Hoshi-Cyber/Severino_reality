export function renderMapEmbed(url) {
  return `<iframe class="map-embed" src="${url}" allowfullscreen="" loading="lazy"></iframe>`;
}
