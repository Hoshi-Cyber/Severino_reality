export function renderPageLoader() {
  return `<div class="page-loader"><div class="spinner"></div></div>`;
}
