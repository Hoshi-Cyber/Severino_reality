export function renderFloatingContactWidget(data) {
  return `<a href="${data.url}" class="floating-contact-widget"><i class="${data.icon}"></i></a>`;
}
